# Psicoativa Deploy Check
Projeto mínimo Next.js para testar deploy na Vercel.
- `npm install`
- `npm run dev`
- Deploy padrão na Vercel (Next.js).
