export const metadata = { title: 'Psicoativa Cognitive Games', description: 'Jogos cognitivos' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="pt-BR"><body>{children}</body></html>)
}