'use client'
import React, { useState } from 'react'
export default function Home(){return <main style={{padding:24}}><h1>OK</h1></main>}